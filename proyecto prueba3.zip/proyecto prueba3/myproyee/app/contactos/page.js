import React from 'react';

const Page = () => {
  return (
    <main>
      <div className="container mx-auto p-4">
        <div className="row flex flex-wrap">
          <div className="col-lg-6 p-4 bg-white rounded-lg shadow-lg">
            <h1 className="text-3xl font-bold mb-4 text-blue-700">Contacto</h1>
            <p className="text-blue-900">Si tienes alguna duda, comentario o sugerencia, por favor,</p>
            <p className="text-blue-900">llena el siguiente formulario y nos pondremos en contacto contigo a la brevedad.</p>
            <form className="space-y-4">
              <div className="form-group">
                <label htmlFor="nombre" className="block text-lg font-semibold text-blue-700">Nombre:</label>
                <input type="text" className="form-control w-full border border-blue-300 p-2 rounded focus:outline-none focus:ring-2 focus:ring-blue-600" id="nombre" />
              </div>
              <div className="form-group">
                <label htmlFor="email" className="block text-lg font-semibold text-blue-700">Email:</label>
                <input type="email" className="form-control w-full border border-blue-300 p-2 rounded focus:outline-none focus:ring-2 focus:ring-blue-600" id="email" />
              </div>
              <div className="form-group">
                <label htmlFor="mensaje" className="block text-lg font-semibold text-blue-700">Mensaje:</label>
                <textarea className="form-control w-full border border-blue-300 p-2 rounded focus:outline-none focus:ring-2 focus:ring-blue-600" id="mensaje" rows="4"></textarea>
              </div>
              <button type="submit" className="bg-blue-600 text-white rounded-full px-6 py-2 hover:bg-blue-700 transform hover:scale-105 transition duration-200">Enviar</button>
            </form>
          </div>
          <div className="col-lg-6 p-4">
            <h2 className="text-2xl font-bold mb-4 text-blue-700">Información de contacto</h2>
            <p className="text-blue-900">Si prefieres, puedes contactarnos directamente por correo electrónico o por teléfono.</p>
            <ul className="list-disc pl-5 text-blue-900">
              <li><strong>Correo electrónico:</strong> ejemplo@correo.com</li>
              <li><strong>Teléfono:</strong> 123-456-7890</li>
            </ul>
          </div>
        </div>
      </div>
    </main>
  );
}

export default Page;