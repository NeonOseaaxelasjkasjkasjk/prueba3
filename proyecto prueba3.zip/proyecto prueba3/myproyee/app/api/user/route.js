import user from "@/model/User";
import connectDB from "@/lib/connectionDB"
import { NextResponse } from "next/server";

export async function POST(req, res) {
    await connectDB()
    
    const {nombre , edad } = await req.json();

    const person = new user({
        name:nombre,
        age:edad
    })
    await person.save()
    console.log("DATOS RECIBIDOS EN API",nombre , edad)
    return NextResponse.json({ message: 'saved' })
  }

export async function GET() {
    await connectDB()
    const usuarios = await user.find()
    return NextResponse.json(JSON.stringify(usuarios))
}
export async function UPDATE(req, res) {
    return Response.json({message:'Not Implemented yet'})
}
export async function DELETE(req, res) {
    return Response.json({message:'Not Implemented yet'})
}