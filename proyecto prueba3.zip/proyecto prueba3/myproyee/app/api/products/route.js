let products = [
  { id: 12345, name: 'Pizza Italiana', descripcion: "La pizza tiene tomate y jamón", precio: 533, imagen: "product1.jpg" },
  { id: 2, name: 'Pepperoni Pizza', descripcion: "Pizza con pepperoni", precio: 1257, imagen: "product2.png" },
  { id: 12346, name: "Pizza 3 Quesos", descripcion: "Pizza que tiene 3 quesos diferentes", precio: 1000, imagen: "product3.webp" },
  { id: 5432, name: "Pizza 3 Estaciones", descripcion: "Tiene 3 mitades", precio: 1257, imagen: "product4.png" }
];

// GET method
export async function GET(req) {
  return new Response(JSON.stringify(products), {
    headers: { 'Content-Type': 'application/json' },
  });
}

// POST method
export async function POST(req) {
  const body = await req.json();
  const newProduct = { ...body, id: Date.now().toString() };
  products.push(newProduct);
  return new Response(JSON.stringify(newProduct), {
    status: 201,
    headers: { 'Content-Type': 'application/json' },
  });
}

// PUT method
export async function PUT(req) {
  const body = await req.json();
  const { id, ...updatedProduct } = body;
  let updated = false;
  products = products.map(product => {
    if (product.id === id) {
      updated = true;
      return { ...product, ...updatedProduct };
    }
    return product;
  });

  if (updated) {
    return new Response(JSON.stringify({ message: 'Product updated', updatedProduct }), {
      headers: { 'Content-Type': 'application/json' },
    });
  } else {
    return new Response(JSON.stringify({ error: 'Product not found' }), {
      status: 404,
      headers: { 'Content-Type': 'application/json' },
    });
  }
}

// DELETE method
export async function DELETE(req) {
  const body = await req.json();
  const { id } = body;
  const initialLength = products.length;
  products = products.filter(product => product.id !== id);

  if (products.length < initialLength) {
    return new Response(JSON.stringify({ message: 'Product deleted' }), {
      headers: { 'Content-Type': 'application/json' },
    });
  } else {
    return new Response(JSON.stringify({ error: 'Product not found' }), {
      status: 404,
      headers: { 'Content-Type': 'application/json' },
    });
  }
}
