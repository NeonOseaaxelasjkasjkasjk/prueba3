"use client";

import { useState, useEffect } from 'react';
import Hero from '@/components/Hero';
import Card from '@/components/Card';
import products from '@/mockup/products.json';

export default function Home() {
  const [productos, setProductos] = useState([]);
  const [isLoading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/products', { // Corregido el path a '/api/products'
      method: 'GET',
    })
      .then((res) => res.json())
      .then((data) => {
        setProductos(data); // Ya no es necesario JSON.parse
        console.log(data); // Ajustado para mostrar los datos sin parsear
        setLoading(false);
      })
      .catch((error) => {
        console.error('Error fetching products:', error);
        setLoading(false);
      });
  }, []);

  if (isLoading) return <p>Espere un momento...</p>; // Cambiado para corrección del mensaje

  return (
    <main className="mx-auto max-w-6xl p-4">
      <Hero />
      <div>
        <h2 className='font-bold text-2xl text-center m-4'>Productos</h2>
        <div className='grid grid-cols-4 gap-4'>
          {productos.map((element) => (
            <Card key={element.id} dato={element} />
          ))}
        </div>
      </div>
    </main>
  );
}
