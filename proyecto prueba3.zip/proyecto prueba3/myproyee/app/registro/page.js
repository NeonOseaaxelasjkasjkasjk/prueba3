"use client";
import { useState } from "react";

const Page = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [usuario, setUsuario] = useState('');

  const handleFormSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch('/api/register', {
        method: 'POST',
        body: JSON.stringify({ usuario, email, password }),
        headers: { 'Content-Type': 'application/json' }
      });
      if (response.ok) {
        console.log("Registro exitoso");
      } else {
        console.error("Error en el registro");
      }
    } catch (error) {
      console.error("Error en la petición:", error);
    }
  }

  return (
    <section className="relative min-h-screen">
      <div className="absolute inset-0">
        <img
          src={'/assets/img/mockups/autobus.gif'}
          alt="GIF de fondo"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gray-900 bg-opacity-50"></div>
      </div>
      <div className="relative z-10 flex items-center justify-center min-h-screen">
        <div className="w-full max-w-md p-8 bg-white bg-opacity-90 rounded-lg shadow-lg">
          <h1 className="text-center text-2xl mb-4">Registro</h1>
          <form className="space-y-4" onSubmit={handleFormSubmit}>
            <input
              type="text"
              placeholder="Escribe tu usuario"
              value={usuario}
              onChange={e => setUsuario(e.target.value)}
              className="w-full p-2 border rounded"
            />
            <input
              type="email"
              placeholder="Escribe tu Email"
              value={email}
              onChange={e => setEmail(e.target.value)}
              className="w-full p-2 border rounded"
            />
            <input
              type="password"
              placeholder="Escribe Clave"
              value={password}
              onChange={e => setPassword(e.target.value)}
              className="w-full p-2 border rounded"
            />
            <button
              type="submit"
              className="w-full bg-blue-600 text-white p-2 rounded hover:bg-blue-700"
            >
              Registrar
            </button>
          </form>
        </div>
      </div>
    </section>
  );
}

export default Page;