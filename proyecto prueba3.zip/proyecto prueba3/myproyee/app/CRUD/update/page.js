app.put('/api/register/:id', async (req, res) => {
    try {
    const item = await Item.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
    if (!item) return res.status(404).send('Ítem no encontrado');
    res.send(item);
    } catch (err) {
    res.status(400).send(err);
    }
});