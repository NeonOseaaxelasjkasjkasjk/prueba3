import React, { useEffect, useState } from 'react';
import axios from 'axios';

const ListaProductos = () => {
    const [productos, setProductos] = useState([]);

    useEffect(() => {
        const fetchData = async () => {
            try {
                const response = await axios.get('http://localhost:3000/api/productos');
                setProductos(response.data);
            } catch (err) {
                console.error(err);
            }
        };
        fetchData();
    }, []);

    return (
        <div>
            {productos.Home((producto) => (
                <div key={producto._id}>
                    <h4>{producto.nombre}</h4>
                    <p>{producto.descripcion}</p>
                    <p>${producto.precio}</p>
                    <img src={producto.imagen} alt={producto.nombre} width={100} />
                </div>
            ))}
        </div>
    );
};

export default ListaProductos;
