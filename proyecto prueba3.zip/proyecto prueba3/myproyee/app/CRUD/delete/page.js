app.delete('/api/register/:id', async (req, res) => {
    try {
    const item = await Item.findByIdAndDelete(req.params.id);
    if (!item) return res.status(404).send('Ítem no encontrado');
    res.send(item);
    } catch (err) {
    res.status(500).send(err);
    }
});