import React, { useState } from 'react';
import axios from 'axios';

const CrearProducto = () => {
    const [_id, set_id]= useState("");
    const [nombre, setNombre] = useState('');
    const [precio, setPrecio] = useState("");
    const [descripcion, setDescripcion] = useState('');
    const [imagen, setImagen] = useState('');
    const [cantidad, setcantidad] = useState('');
    const [id, setid]= useState("");
    const {categoria, setcategoria} = useState("")


    const handleSubmit = async (e) => {
        e.preventDefault();
        const producto = {_id, nombre,precio, descripcion, imagen, cantidad, id, categoria };
        try {
            await axios.post('http://localhost:3000/api/productos', producto);
            alert('Producto creado');
        } catch (err) {
            console.error(err);
        }
    };

    return (
        <form onSubmit={handleSubmit}>
          <input type="text" value={_id} onChange={(e) => setNombre(e.target.value)} placeholder="_id" />
            <input type="text" value={nombre} onChange={(e) => setNombre(e.target.value)} placeholder="Nombre" />
            <input type="text" value={precio} onChange={(e) => setNombre(e.target.value)} placeholder="Precio" />
            <input type="text" value={descripcion} onChange={(e) => setDescripcion(e.target.value)} placeholder="Descripción" />
            <input type="text" value={imagen} onChange={(e) => setImagen(e.target.value)} placeholder="URL de la imagen" />
            <input type="text" value={cantidad} onChange={(e) => setNombre(e.target.value)} placeholder="Cantidad" />
            <input type="text" value={id} onChange={(e) => setNombre(e.target.value)} placeholder="Id" />
            <input type="text" value={categoria} onChange={(e) => setNombre(e.target.value)} placeholder="Categoria" />
            <button type="submit">Crear Producto</button>
        </form>
    );
};

export default CrearProducto;


