import Link from 'next/link';

export default function Gestion() {
  return (
    <main className="mx-auto max-w-6xl p-4">
      <h1 className="text-4xl font-bold text-center mb-8">Gestión</h1>
      <p>Esta es la página de gestión.</p>
      <Link href="/productos" className="text-blue-500">Ir a Productos</Link>
    </main>
  );
}
