"use client";

import { useState } from 'react';

const LoginPage = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  const handleFormSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch('/api/login', {
        method: 'POST',
        body: JSON.stringify({ email, password }),
        headers: { 'Content-Type': 'application/json' },
      });

      if (response.ok) {
        const data = await response.json();
        localStorage.setItem('token', data.token);
        setMessage('Inicio de sesión exitoso');
        window.location.href = '/add-product';
      } else {
        const errorData = await response.json();
        setError(errorData.error || 'Error en el inicio de sesión');
      }
    } catch (error) {
      console.error("Error en la solicitud:", error);
      setError('Error en la conexión, por favor intenta de nuevo más tarde');
    }
  }

  return (
    <section className="mt-8">
      <h1 className="text-center text-2xl">Iniciar Sesión</h1>
      <form className="block mx-auto max-w-xs" onSubmit={handleFormSubmit}>
        <input
          type="email"
          placeholder="Escribe tu Email"
          value={email}
          onChange={e => setEmail(e.target.value)}
          required
        />
        <input
          type="password"
          placeholder="Escribe tu Clave"
          value={password}
          onChange={e => setPassword(e.target.value)}
          required
        />
        <button
          type="submit"
          className="bg-blue-600 text-white p-2 rounded mt-4 hover:bg-blue-700"
        >
          Iniciar Sesión
        </button>
        {message && <p className="text-green-500 text-center mt-2">{message}</p>}
        {error && <p className="text-red-500 text-center mt-2">{error}</p>}
      </form>
    </section>
  );
}

export default LoginPage;
