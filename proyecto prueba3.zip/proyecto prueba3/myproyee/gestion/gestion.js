import { useState, useEffect } from 'react';

export default function Gestion() {
  const [productos, setProductos] = useState([]);
  const [newProduct, setNewProduct] = useState('');
  const [editProduct, setEditProduct] = useState({ id: '', name: '' });
  const [isLoading, setLoading] = useState(true);

  useEffect(() => {
    fetch('/api/products')
      .then((res) => res.json())
      .then((data) => {
        setProductos(data);
        setLoading(false);
      })
      .catch((error) => {
        console.error('Error fetching products:', error);
        setLoading(false);
      });
  }, []);

  const handleAddProduct = async () => {
    if (!newProduct.trim()) return;
    try {
      const response = await fetch('/api/products', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: newProduct }),
      });
      if (!response.ok) throw new Error('Failed to add product');
      const data = await response.json();
      setProductos([...productos, data]);
      setNewProduct('');
    } catch (error) {
      console.error('Error adding product:', error);
    }
  };

  const handleUpdateProduct = async () => {
    if (!editProduct.name.trim()) return;
    try {
      const response = await fetch('/api/products', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: editProduct.id, updatedProduct: { name: editProduct.name } }),
      });
      if (!response.ok) throw new Error('Failed to update product');
      const data = await response.json();
      setProductos(productos.map(product =>
        product.id === data.id ? data : product
      ));
      setEditProduct({ id: '', name: '' });
    } catch (error) {
      console.error('Error updating product:', error);
    }
  };

  const handleDeleteProduct = async (id) => {
    try {
      const response = await fetch('/api/products', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ deleteId: id }),
      });
      if (!response.ok) throw new Error('Failed to delete product');
      setProductos(productos.filter(product => product.id !== id));
    } catch (error) {
      console.error('Error deleting product:', error);
    }
  };

  if (isLoading) return <p className="text-center text-gray-600">Cargando productos...</p>;

  return (
    <main className="bg-gradient-to-r from-blue-200 to-purple-300 min-h-screen p-8">
      <div className="container mx-auto max-w-6xl bg-white p-6 rounded-lg shadow-lg">
        <h1 className="text-4xl font-bold text-center mb-8 text-gray-800">Gestión de Productos</h1>

        <div className="mb-8 p-6 border rounded-lg shadow-md bg-white">
          <h2 className="text-2xl font-semibold mb-4 text-gray-700">Agregar Producto</h2>
          <div className="flex items-center space-x-4">
            <input
              type="text"
              value={newProduct}
              onChange={(e) => setNewProduct(e.target.value)}
              placeholder="Nombre del producto"
              className="flex-1 border border-gray-300 rounded-lg p-2"
            />
            <button
              onClick={handleAddProduct}
              className="bg-blue-600 text-white rounded-lg px-4 py-2 hover:bg-blue-700 transition"
            >
              Agregar
            </button>
          </div>
        </div>

        <div className="mb-8 p-6 border rounded-lg shadow-md bg-white">
          <h2 className="text-2xl font-semibold mb-4 text-gray-700">Actualizar Producto</h2>
          <div className="flex items-center space-x-4 mb-4">
            <select
              value={editProduct.id}
              onChange={(e) => setEditProduct({
                ...editProduct,
                id: e.target.value,
                name: productos.find(product => product.id === e.target.value)?.name || ''
              })}
              className="flex-1 border border-gray-300 rounded-lg p-2"
            >
              <option value="">Seleccione un producto</option>
              {productos.map(product => (
                <option key={product.id} value={product.id}>{product.name}</option>
              ))}
            </select>
            <input
              type="text"
              value={editProduct.name}
              onChange={(e) => setEditProduct({ ...editProduct, name: e.target.value })}
              placeholder="Nuevo nombre del producto"
              className="flex-1 border border-gray-300 rounded-lg p-2"
            />
            <button
              onClick={handleUpdateProduct}
              className="bg-green-600 text-white rounded-lg px-4 py-2 hover:bg-green-700 transition"
            >
              Actualizar
            </button>
          </div>
        </div>

        <div className="p-6 border rounded-lg shadow-md bg-white">
          <h2 className="text-2xl font-semibold mb-4 text-gray-700">Lista de Productos</h2>
          <ul className="list-disc pl-5">
            {productos.map(product => (
              <li key={product.id} className="mb-4 flex items-center justify-between">
                <div>
                  <span className="font-medium text-gray-800">{product.name}</span> - ${product.precio}
                </div>
                <button
                  onClick={() => handleDeleteProduct(product.id)}
                  className="bg-red-600 text-white rounded-lg px-4 py-2 hover:bg-red-700 transition"
                >
                  Eliminar
                </button>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </main>
  );
}
