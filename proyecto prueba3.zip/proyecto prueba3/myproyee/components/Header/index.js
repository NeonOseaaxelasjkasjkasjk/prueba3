import Link from 'next/link';


const Header = () => {
  return (
    <header className="flex items-center justify-between z-50 relative">
      <nav className="flex gap-10 items-center text-gray-600 font-semibold">
        <Link href="/model" className="text-red-600 text-2xl font-semibold">&#127789;Pizza Home</Link>
        <Link href="/">INICIO</Link>
        <Link href="/page/" className="">Gestion de productos</Link>
        <Link href="/product">productos</Link>
      </nav>
      <div>
        <Link href="/login" className="rounded-full px-6 py-1">Iniciar Sesión</Link>
        <Link href="/registro" className="bg-red-700 text-white rounded-full px-6 py-1">Registro</Link>
        <Link href="/admin" legacyBehavior><a>Admin</a>
        </Link>
      </div>
      <div className="fixed bottom-0 right-0 m-4">
        <Link href="/contactos" className="bg-red-500 text-white py-2 px-4 rounded-full shadow-lg">Contactos</Link>
      </div>
    </header>
  );
};

export default Header;
