

const index = ({texto='Mockup'}) => {
  return (
    <button className="bg-orange-700 text-white rounded-full px-5 py-3 hover:scale-105">{texto}</button>
  )
}

export default index