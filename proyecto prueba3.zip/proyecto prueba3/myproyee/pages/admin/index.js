import { useState } from 'react';
import axios from 'axios';

export default function Admin() {
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [price, setPrice] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [imagePreview, setImagePreview] = useState(''); // Estado para la vista previa de la imagen

  const handleAddProduct = async (e) => {
    e.preventDefault();
    if (!imageUrl) {
      console.error('Image URL is required');
      return;
    }
    const newProduct = { name, description, price, imagen: imageUrl };
    try {
      const response = await axios.post('/api/products', newProduct);
      console.log('Producto añadido:', response.data);
      // Clear form fields after submission
      setName('');
      setDescription('');
      setPrice('');
      setImageUrl('');
      setImagePreview(''); // Limpiar vista previa
    } catch (error) {
      console.error('Error al añadir el producto:', error);
    }
  };

  // Manejar el cambio en el campo de URL de la imagen y actualizar la vista previa
  const handleImageUrlChange = (e) => {
    const url = e.target.value;
    setImageUrl(url);
    setImagePreview(url); // Actualizar vista previa
  };

  return (
    <div>
      <h1>Admin Panel</h1>
      <form onSubmit={handleAddProduct}>
        <input
          type="text"
          placeholder="Product Name"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
        <input
          type="text"
          placeholder="Description"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
        />
        <input
          type="number"
          placeholder="Price"
          value={price}
          onChange={(e) => setPrice(e.target.value)}
        />
        <input
          type="text"
          placeholder="Image URL"
          value={imageUrl}
          onChange={handleImageUrlChange} // Usa la función actualizada
        />
        {/* Mostrar vista previa de la imagen y detalles del producto */}
        {imagePreview && (
          <div>
            <h2>Product Preview:</h2>
            <div>
              <h3>{name || 'Product Name'}</h3>
              <p>{description || 'Product Description'}</p>
              <p>Price: ${price || '0'}</p>
              <img src={imagePreview} alt="Product Preview" style={{ maxWidth: '200px', maxHeight: '200px' }} />
            </div>
          </div>
        )}
        <button type="submit">Add Product</button>
      </form>
    </div>
  );
}
