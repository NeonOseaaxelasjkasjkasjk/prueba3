import { useEffect, useState } from 'react';
import Link from 'next/link';

const ProductsPage = () => {
  const [products, setProducts] = useState([]);
  const [editingProduct, setEditingProduct] = useState(null);
  const [formData, setFormData] = useState({ name: '', descripcion: '', precio: '', imagen: '' });

  useEffect(() => {
    fetch('/api/products')
      .then(response => response.json())
      .then(data => setProducts(data));
  }, []);

  const handleDelete = async (id) => {
    await fetch(`/api/products`, {
      method: 'DELETE',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id })
    });
    setProducts(products.filter(product => product.id !== id));
  };

  const handleEdit = (product) => {
    setEditingProduct(product);
    setFormData({ ...product });
  };

  const handleInputChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSave = async () => {
    await fetch(`/api/products`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id: editingProduct.id, ...formData })
    });
    setProducts(products.map(product => (product.id === editingProduct.id ? { ...product, ...formData } : product)));
    setEditingProduct(null);
    setFormData({ name: '', descripcion: '', precio: '', imagen: '' });
  };

  return (
    <div>
      <h1>Productos</h1>
      <ul>
        {products.map(product => (
          <li key={product.id}>
            <h2>{product.name}</h2>
            <p>{product.descripcion}</p>
            <p>Precio: ${product.precio}</p>
            <img src={`/img/${product.imagen}`} alt={product.name} />
            <button onClick={() => handleEdit(product)}>Editar</button>
            <button onClick={() => handleDelete(product.id)}>Eliminar</button>
          </li>
        ))}
      </ul>

      {editingProduct && (
        <div>
          <h2>Editar Producto</h2>
          <input
            type="text"
            name="name"
            value={formData.name}
            onChange={handleInputChange}
            placeholder="Nombre"
          />
          <input
            type="text"
            name="descripcion"
            value={formData.descripcion}
            onChange={handleInputChange}
            placeholder="Descripción"
          />
          <input
            type="number"
            name="precio"
            value={formData.precio}
            onChange={handleInputChange}
            placeholder="Precio"
          />
          <input
            type="text"
            name="imagen"
            value={formData.imagen}
            onChange={handleInputChange}
            placeholder="Imagen"
          />
          <button onClick={handleSave}>Guardar</button>
          <button onClick={() => setEditingProduct(null)}>Cancelar</button>
        </div>
      )}
    </div>
  );
};

export default ProductsPage;
