"use client";

import { useState, useEffect } from 'react';

export default function Home() {
  const [productos, setProductos] = useState([]);
  const [isLoading, setLoading] = useState(true);
  const [newProduct, setNewProduct] = useState('');
  const [editProduct, setEditProduct] = useState({ id: '', name: '' });

  useEffect(() => {
    fetch('/api/products')
      .then((res) => res.json())
      .then((data) => {
        setProductos(data);
        setLoading(false);
      })
      .catch((error) => {
        console.error('Error fetching products:', error);
        setLoading(false);
      });
  }, []);

  const handleAddProduct = async () => {
    if (!newProduct.trim()) return;
    const response = await fetch('/api/products', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: newProduct }),
    });
    const data = await response.json();
    setProductos([...productos, data]);
    setNewProduct('');
  };

  const handleUpdateProduct = async () => {
    if (!editProduct.name.trim()) return;
    const response = await fetch('/api/products', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id: editProduct.id, updatedProduct: { name: editProduct.name } }),
    });
    const data = await response.json();
    setProductos(productos.map(product =>
      product.id === data.id ? data : product
    ));
    setEditProduct({ id: '', name: '' });
  };

  const handleDeleteProduct = async (id) => {
    await fetch('/api/products', {
      method: 'DELETE',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ deleteId: id }),
    });
    setProductos(productos.filter(product => product.id !== id));
  };

  if (isLoading) return <p>Espere un momento...</p>;

  return (
    <main className="mx-auto max-w-6xl p-4">
      <h1 className="text-4xl font-bold text-center mb-8">Gestión de Productos</h1>

      <div className='mb-4'>
        <h2 className='font-bold text-xl'>Agregar Producto</h2>
        <input
          type="text"
          value={newProduct}
          onChange={(e) => setNewProduct(e.target.value)}
          placeholder="Nombre del producto"
          className="border p-2 mr-2"
        />
        <button onClick={handleAddProduct} className="p-2 bg-blue-500 text-white">Agregar</button>
      </div>

      <div className='mb-4'>
        <h2 className='font-bold text-xl'>Actualizar Producto</h2>
        <select
          value={editProduct.id}
          onChange={(e) => setEditProduct({
            ...editProduct,
            id: e.target.value,
            name: productos.find(product => product.id === e.target.value)?.name || ''
          })}
          className="border p-2 mr-2"
        >
          <option value="">Seleccione un producto</option>
          {productos.map(product => (
            <option key={product.id} value={product.id}>{product.name}</option>
          ))}
        </select>
        <input
          type="text"
          value={editProduct.name}
          onChange={(e) => setEditProduct({ ...editProduct, name: e.target.value })}
          placeholder="Nuevo nombre del producto"
          className="border p-2 mr-2"
        />
        <button onClick={handleUpdateProduct} className="p-2 bg-green-500 text-white">Actualizar</button>
      </div>

      <div>
        <h2 className='font-bold text-xl mb-4'>Lista de Productos</h2>
        <ul className="list-disc pl-5">
          {productos.map(product => (
            <li key={product.id} className="mb-2">
              {product.name}
              <button
                onClick={() => handleDeleteProduct(product.id)}
                className="ml-2 p-1 bg-red-500 text-white"
              >
                Eliminar
              </button>
            </li>
          ))}
        </ul>
      </div>
    </main>
  );
}
